//Calling API and modeling data for each chart//
const resochart = async () => {
    const response = await fetch('http://localhost:8083/statistics/resolutionbar/201809302359BiebertalV010/2021-01-01/2021-01-03');
    const json = await response.json();
    const data = json.data
    const Ansichten = data.map(obj => obj.Ansichten)
    const resolution = data.map(obj => obj.resolution)
    return {
        Ansichten, resolution
    }
}

async function resochartcheck() {
    let results = await resochart()
    console.log(results)
}
resochartcheck()

//Error handling//
function checkStatus(response) {
    if (response.ok) {
        return Promise.resolve(response);
    } else {
        return Promise.reject(new Error(response.statusText));
    }
}

//Charts//
let createResochart

//Function for the Chart
async function printResochart() {
    let { Ansichten, resolution } = await resochart()

    let Resochart = document.getElementById('Resochart').getContext('2d');

    Chart.defaults.global.defaultFontFamily = 'Red Hat Text';
    Chart.defaults.global.defaultFontSize = 12;

    createResochart = new Chart(Resochart, {
        type: 'bar',
        data: {
            labels: resolution,
            datasets: [{
                label: '# of Votes',
                data: Ansichten,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
}

//Load function
printResochart()

function test(){
    console.log(single_videoID);
    return single_videoID;
}
test()