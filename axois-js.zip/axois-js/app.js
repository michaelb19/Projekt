const videoList = document.getElementById('videosList');
const searchBar = document.getElementById('searchBar');
let videoIDS = [];
var single_videoID = '';

console.log(searchBar);
searchBar.addEventListener('keyup', (e) => {
    if(searchBar.value != ""){
      videosList.classList.remove("hidden");
    // elseif(single_videoID != null){
    //   videoList.classList.add("hidden");
    // }
    }else {
      videoList.classList.add("hidden");
    }
    const searchString = e.target.value.toLowerCase();
    console.log(e.target.value);
    const filteredVideos = videoIDS.filter((video) => {

        return (
            video.toLowerCase().includes(searchString)


        );
    });
    displayVideos(filteredVideos);
    console.log(filteredVideos);
});

const loadVideos = async () => {
    try {
        const res = await fetch('https://biebertal.mach-mit.tv/video/list?tags=');

        videoIDS = await res.json();
        displayVideos(videoIDS);
    } catch (err) {
        console.error(err);

    }
};
//
// let test = ["a","b","c","d"];
// console.log(test);
//
// test = test.map( (incoming) => {
//   return "something>" + incoming;
// });
//
// console.log(test);
// function load_single_video(input){
//   const loadSingleVideo = async () => {
//       try {
//           const res = await fetch('https://biebertal.mach-mit.tv/video/list?tags=' + input);
//
//           single_videoID_response = await res.json();
//           console.log(single_videoID_response);
// //            displayVideos(videoID);
//       } catch (err) {
//           console.error(err);
//
//       }
//   };
//   loadSingleVideo();
// }



const displayVideos = (videoss) => {

  single_videoID = "";
  if(videoss.length == 1){
    // load_single_video(videoss[0]);
   single_videoID = videoss[0];
  }
    const htmlString = videoss.map((video) => {
            return `
            <li class="video">
                <h2 onclick="fill_search_input(this.innerHTML)">${video}</h2>

            </li>

        `;
        })
    .join('');
    videosList.innerHTML = htmlString;
};

loadVideos();

function fill_search_input(title){
  searchBar.value = title;
  searchBar.dispatchEvent(new Event('keyup'));
  videoList.classList.add("hidden");
}
